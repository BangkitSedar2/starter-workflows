<Do not use this to ask about lost codes or accounts>
<More info here: https://authenticator.cc/docs/en/lost-codes>
<You can also open an issue by Tweeting with #AuthenticatorFeedback>

