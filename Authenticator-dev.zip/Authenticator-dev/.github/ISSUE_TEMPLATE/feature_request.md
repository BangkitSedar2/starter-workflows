---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

<You can also suggest feedback by Tweeting with #AuthenticatorFeedback>

**Describe the feature you want:**


**Why do you want this feature in Authenticator?**
