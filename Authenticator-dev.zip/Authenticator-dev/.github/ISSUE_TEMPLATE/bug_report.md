---
name: Bug report
about: Report a bug in Authenticator
title: ''
labels: bug
assignees: ''

---

<Do not use this to ask about lost codes or accounts>
<More info here: https://authenticator.cc/docs/en/lost-codes>

**Describe the bug:** <Describe the issue with Authenticator> 


**Platform:** <This is required>
 - Browser: [Chrome, Firefox]
 - Browser Version:
