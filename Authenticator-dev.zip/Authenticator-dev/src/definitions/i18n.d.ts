interface I18nMessage {
  [key: string]: { message: string; description: string };
}
