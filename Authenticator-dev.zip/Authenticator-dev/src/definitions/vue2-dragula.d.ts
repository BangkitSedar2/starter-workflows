declare module "vue2-dragula" {
  import { PluginFunction, VueConstructor } from "vue";

  const Vue2Dragula: PluginFunction<VueConstructor>;
}
