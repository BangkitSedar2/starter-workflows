<template>
  <div class="text">
    {{ i18n.loading }}
  </div>
</template>
<script lang="ts">
import Vue from "vue";

export default Vue.extend({});
</script>
